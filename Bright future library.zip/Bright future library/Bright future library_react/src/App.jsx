import Header from './components/Header.jsx';
import ServiceCard from './components/ServiceCard.jsx';
import EventCard from './components/EventCard.jsx';
import BookCard from './components/BookCard.jsx';
import ContactForm from './components/ContactForm.jsx';
import Footer from './components/Footer.jsx';
import { books, events, services } from './data/libraryData.js';
import './App.css';

function SectionHeading({ eyebrow, title, description, light = false }) {
  return (
    <div className={`section-heading${light ? ' section-heading-light' : ''}`}>
      <p className="eyebrow">{eyebrow}</p>
      <h2>{title}</h2>
      {description && <p className="section-description">{description}</p>}
    </div>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <main>
        <section className="hero" id="home" aria-labelledby="home-title">
          <div className="hero-inner">
            <div className="hero-copy">
              <p className="hero-kicker"><span /> A place to learn, grow & belong</p>
              <h1 id="home-title">Welcome to<br /><em>Bright Future</em> Library</h1>
              <p className="hero-intro">
                A welcoming space where stories spark ideas, students find support,
                and everyone can discover the joy of learning.
              </p>
              <div className="hero-actions">
                <a className="button button-gold" href="#books">Explore featured books <span aria-hidden="true">↗</span></a>
                <a className="text-link" href="#services">Discover our services <span aria-hidden="true">→</span></a>
              </div>
              <div className="hero-note"><span className="note-mark">✳</span> Open to curious minds of every age</div>
            </div>
            <div className="hero-art" aria-hidden="true">
              <div className="art-sun" />
              <div className="art-circle" />
              <div className="art-book art-book-one"><span>READ<br />GROW<br />DREAM</span></div>
              <div className="art-book art-book-two"><span>KNOWLEDGE<br />IS A JOURNEY</span></div>
              <div className="art-shelf" />
              <span className="art-star star-one">✳</span>
              <span className="art-star star-two">✦</span>
              <span className="art-caption">Open a book.<br />Open a world.</span>
            </div>
          </div>
          <div className="hero-bottom"><span>01 / 06</span><span>Scroll to explore <b aria-hidden="true">↓</b></span></div>
        </section>

        <section className="about-section section-pad" id="about" aria-labelledby="about-title">
          <div className="about-stamp" aria-hidden="true"><span>READ<br />LEARN<br />CONNECT</span></div>
          <div className="about-content">
            <p className="eyebrow">A community built on curiosity</p>
            <h2 id="about-title">Knowledge belongs<br />to <em>everyone.</em></h2>
            <div className="about-columns">
              <p>
                Bright Future Library exists to make reading, learning, and useful
                educational resources more accessible to our community. It is a
                place to explore new ideas and nurture a lifelong love of books.
              </p>
              <p>
                Students can find a supportive environment for study, families can
                enjoy stories together, and community members of every age can
                learn at their own pace. There is always something new to discover.
              </p>
            </div>
            <a className="text-link dark-link" href="#contact">Come say hello <span aria-hidden="true">→</span></a>
          </div>
        </section>

        <section className="services-section section-pad" id="services" aria-labelledby="services-title">
          <SectionHeading
            eyebrow="Here for your next chapter"
            title="A little something for everyone."
            description="Whether you are here to focus, browse, or try something new, our library is ready to welcome you."
          />
          <div className="services-grid">
            {services.map((service) => <ServiceCard key={service.id} service={service} />)}
          </div>
        </section>

        <section className="events-section section-pad" id="events" aria-labelledby="events-title">
          <div className="events-intro">
            <SectionHeading
              eyebrow="Make time for a good story"
              title="On the calendar."
              description="Gather, listen, read, and share. Join one of our upcoming sample events."
            />
            <span className="events-decoration" aria-hidden="true">✳</span>
          </div>
          <div className="events-grid">
            {events.map((event) => <EventCard key={event.id} event={event} />)}
          </div>
        </section>

        <section className="books-section section-pad" id="books" aria-labelledby="books-title">
          <div className="books-heading">
            <SectionHeading
              eyebrow="Picked for your imagination"
              title="Featured books."
              description="A few thoughtful reads to begin with. Find a new favourite, or revisit an old one."
            />
            <span className="book-shelf-label">THE READING ROOM · VOL. 01</span>
          </div>
          <div className="books-grid">
            {books.map((book) => <BookCard key={book.id} book={book} />)}
          </div>
        </section>

        <section className="contact-section section-pad" id="contact" aria-labelledby="contact-title">
          <div className="contact-info">
            <p className="eyebrow">We would love to hear from you</p>
            <h2 id="contact-title">Let’s start a<br /><em>conversation.</em></h2>
            <p className="contact-lead">
              Have a question or want to learn more? Send us a note or use the
              demonstration contact details below.
            </p>
            <div className="contact-details">
              <div><span>Address</span><p>123 Community Road,<br />Your Town</p></div>
              <div><span>Telephone</span><p><a href="tel:+250700000000">+250 700 000 000</a></p></div>
              <div><span>Email</span><p><a href="mailto:info@brightfuturelibrary.example">info@brightfuturelibrary.example</a></p></div>
            </div>
            <p className="demo-note">These are demonstration contact details.</p>
          </div>
          <div className="form-panel">
            <div className="form-panel-heading">
              <span>01 <i>/</i> YOUR MESSAGE</span>
              <span aria-hidden="true">✳</span>
            </div>
            <ContactForm />
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
