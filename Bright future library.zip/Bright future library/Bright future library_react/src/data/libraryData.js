export const services = [
  {
    id: 'borrowing',
    number: '01',
    title: 'Book Borrowing and Returning',
    description:
      'Explore a welcoming collection of books and take your next great read home.',
    icon: '↗',
  },
  {
    id: 'internet',
    number: '02',
    title: 'Internet and Computer Access',
    description:
      'Use computers and internet access for research, learning, and everyday study.',
    icon: '⌘',
  },
  {
    id: 'spaces',
    number: '03',
    title: 'Reading and Study Spaces',
    description:
      'Find a comfortable, quiet place to read, focus, and work independently.',
    icon: '▤',
  },
  {
    id: 'workshops',
    number: '04',
    title: 'Educational Workshops and Literacy Programmes',
    description:
      'Take part in learning activities that encourage literacy and lifelong curiosity.',
    icon: '✳',
  },
];

export const events = [
  {
    id: 'reading-competition',
    title: 'Community Reading Competition',
    date: 'November 21, 2026',
    dateTime: '2026-11-21',
    description:
      'A friendly reading competition encouraging students and residents to discover new books and share their knowledge.',
  },
  {
    id: 'storytelling',
    title: 'Children’s Storytelling Session',
    date: 'December 5, 2026',
    dateTime: '2026-12-05',
    description:
      'An interactive storytelling session that helps children develop imagination, listening skills, and a love of reading.',
  },
];

export const books = [
  {
    id: 'little-prince',
    title: 'The Little Prince',
    author: 'Antoine de Saint-Exupéry',
    description:
      'A thoughtful story about friendship, imagination, and understanding what matters most.',
    style: 'cover-gold',
    initials: 'LP',
  },
  {
    id: 'things-fall-apart',
    title: 'Things Fall Apart',
    author: 'Chinua Achebe',
    description:
      'A novel exploring community, tradition, and change in an Igbo society in Nigeria.',
    style: 'cover-rust',
    initials: 'TFA',
  },
  {
    id: 'brief-history',
    title: 'A Brief History of Time',
    author: 'Stephen Hawking',
    description:
      'An introduction to major questions about the universe, space, and time.',
    style: 'cover-blue',
    initials: 'TIME',
  },
];
