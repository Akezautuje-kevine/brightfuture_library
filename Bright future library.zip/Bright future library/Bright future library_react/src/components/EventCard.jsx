export default function EventCard({ event }) {
  return (
    <article className="event-card">
      <div className="event-date">
        <span aria-hidden="true">◷</span>
        <time dateTime={event.dateTime}>{event.date}</time>
      </div>
      <h3>{event.title}</h3>
      <p>{event.description}</p>
      <span className="sample-label">Sample event</span>
    </article>
  );
}
