export default function Footer() {
  return (
    <footer className="site-footer">
      <a className="footer-brand" href="#home">Bright Future Library</a>
      <p>Promoting curiosity, one page at a time.</p>
      <span>© {new Date().getFullYear()} Bright Future Library</span>
    </footer>
  );
}
