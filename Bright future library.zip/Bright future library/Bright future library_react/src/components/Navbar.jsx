import { useState } from 'react';

const links = [
  ['Home', 'home'],
  ['About Us', 'about'],
  ['Services', 'services'],
  ['Events', 'events'],
  ['Featured Books', 'books'],
  ['Contact Us', 'contact'],
];

export default function Navbar() {
 
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="site-nav" aria-label="Main navigation">
      <div className="nav-inner">
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-controls="primary-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span className="menu-icon" aria-hidden="true">{menuOpen ? '×' : '☰'}</span>
          {menuOpen ? 'Close menu' : 'Menu'}
        </button>
        <ul id="primary-navigation" className={menuOpen ? 'nav-links is-open' : 'nav-links'}>
          {links.map(([label, section]) => (
            <li key={section}>
              <a href={`#${section}`} onClick={() => setMenuOpen(false)}>
                {label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}
