export default function BookCard({ book }) {
  return (
    <article className="book-card">
      <div className={`book-cover ${book.style}`} aria-label={`Decorative cover for ${book.title}`}>
        <span className="cover-ornament" aria-hidden="true">{book.initials}</span>
        <span className="cover-title">{book.title}</span>
        <span className="cover-author">{book.author}</span>
      </div>
      <div className="book-copy">
        <p className="eyebrow">A featured read</p>
        <h3>{book.title}</h3>
        <p className="book-author">{book.author}</p>
        <p>{book.description}</p>
      </div>
    </article>
  );
}
