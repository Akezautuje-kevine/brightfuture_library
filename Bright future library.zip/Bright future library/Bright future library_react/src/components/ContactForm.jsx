import { useState } from 'react';

const emptyForm = { name: '', email: '', message: '' };

export default function ContactForm() {
  
  const [values, setValues] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [feedback, setFeedback] = useState('');

  function handleChange(event) {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    setErrors((current) => ({ ...current, [name]: '' }));
    setFeedback('');
  }

  function handleSubmit(event) {
    event.preventDefault();
    setFeedback('');

  
    const nextErrors = {};
    if (!values.name.trim()) nextErrors.name = 'Please enter your full name.';
    if (!values.email.trim()) {
      nextErrors.email = 'Please enter your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
      nextErrors.email = 'Please enter a valid email address.';
    }
    if (!values.message.trim()) nextErrors.message = 'Please enter a message.';

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setValues(emptyForm);
    setFeedback(
      'Thank you! Your message has been validated successfully. This is a demonstration form; no message has been sent.',
    );
  }

  return (
    <form className="contact-form" noValidate onSubmit={handleSubmit}>
      <div className="form-field">
        <label htmlFor="full-name">Full Name</label>
        <input
          id="full-name"
          name="name"
          type="text"
          autoComplete="name"
          value={values.name}
          onChange={handleChange}
          aria-invalid={Boolean(errors.name)}
          aria-describedby={errors.name ? 'name-error' : undefined}
        />
        {errors.name && <p className="field-error" id="name-error">{errors.name}</p>}
      </div>
      <div className="form-field">
        <label htmlFor="email-address">Email Address</label>
        <input
          id="email-address"
          name="email"
          type="email"
          autoComplete="email"
          value={values.email}
          onChange={handleChange}
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? 'email-error' : undefined}
        />
        {errors.email && <p className="field-error" id="email-error">{errors.email}</p>}
      </div>
      <div className="form-field">
        <label htmlFor="message">Message</label>
        <textarea
          id="message"
          name="message"
          rows="5"
          value={values.message}
          onChange={handleChange}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? 'message-error' : undefined}
        />
        {errors.message && <p className="field-error" id="message-error">{errors.message}</p>}
      </div>
      <button className="button button-gold form-submit" type="submit">
        Send Message <span aria-hidden="true">↗</span>
      </button>
      <p className="form-feedback" role="status" aria-live="polite">{feedback}</p>
    </form>
  );
}
