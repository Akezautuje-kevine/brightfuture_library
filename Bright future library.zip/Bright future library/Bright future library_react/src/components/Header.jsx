import Navbar from './Navbar.jsx';

export default function Header() {
  return (
    <>
      <header className="site-header">
        <div className="header-top">
          <a className="brand" href="#home" aria-label="Bright Future Library home">
            <span className="brand-mark" aria-hidden="true">
              <span />
              <span />
            </span>
            <span className="brand-name">
              <strong>Bright Future</strong>
              <span>LIBRARY</span>
            </span>
          </a>
          <p className="mission">
            Promoting reading, supporting students, and connecting our community
            to knowledge.
          </p>
          <a className="header-contact" href="#contact">
            Get in touch <span aria-hidden="true">↗</span>
          </a>
        </div>
      </header>
      <Navbar />
    </>
  );
}
